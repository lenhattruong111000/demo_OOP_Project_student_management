package main;

import selectFeatures.SelectFeatures;

public class Main {
    
 
    public static void main(String[] args) {
      SelectFeatures.selectFeartures();
      
       
    }
    
}